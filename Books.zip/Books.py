# run on command prompt- streamlit run Books.py

import streamlit as st
import pymongo
import pandas as pd
import plotly.express as px
from datetime import datetime

# MongoDB Connection
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client["mydb1"]
books_collection = db["books"]

# Initialize session state variables
if 'book_title' not in st.session_state:
    st.session_state['book_title'] = ''
if 'book_author' not in st.session_state:
    st.session_state['book_author'] = ''
if 'book_added' not in st.session_state:
    st.session_state['book_added'] = False

# Function to add a new book
def add_book(title, author, total_pages, date_added):
    # Convert the date_added from date to datetime
    date_added = datetime.combine(date_added, datetime.min.time())
    
    book = {
        "title": title,
        "author": author,
        "total_pages": total_pages,
        "pages_read": 0,
        "date_added": date_added
    }
    books_collection.insert_one(book)

# Function to log reading progress
def log_reading_progress(book_id, pages_read):
    books_collection.update_one({"_id": book_id}, {"$inc": {"pages_read": pages_read}})

# Function to update an existing book
def update_book(book_id, title, author):
    books_collection.update_one(
        {"_id": book_id},
        {"$set": {"title": title, "author": author}}
    )

# Function to delete a book
def delete_book(book_id):
    books_collection.delete_one({"_id": book_id})

# Function to generate report with Pie Chart and Line Chart
def generate_report():
    books = list(books_collection.find())
    
    if not books:
        st.write("No books available to generate a report.")
        return

    # Create DataFrame for books
    book_data = []
    for book in books:
        book_data.append({
            'Book': book.get('title', 'Unknown Title'),
            'Author': book.get('author', 'Unknown Author'),
            'Pages_Read': book.get('pages_read', 0),
            'Total_Pages': book.get('total_pages', 0),
            'Date_Added': book.get('date_added', datetime.now())
        })
    
    df = pd.DataFrame(book_data)

    # Format the date to display without the time
    df['Date_Added'] = df['Date_Added'].dt.date

    # Remove the index column before displaying the table
    df = df.reset_index(drop=True)

    # Generate Pie Chart for books that are still being read
    author_book_summary = df[df['Pages_Read'] < df['Total_Pages']].groupby(['Author', 'Book'])['Pages_Read'].sum().reset_index()
    if not author_book_summary.empty:
        st.write("Currently Reading Books")
        pie_fig = px.pie(author_book_summary, values='Pages_Read', names='Book',
                         color_discrete_sequence=px.colors.sequential.Tealgrn,
                         hover_data=['Author'])  # Hover shows the Author
        st.plotly_chart(pie_fig)

    # Display the DataFrame as a table for a tabular report
    st.write("### Reading Habits Report")
    st.table(df[['Book', 'Author', 'Pages_Read', 'Total_Pages', 'Date_Added']])

    # Display total reading progress
    st.write("### Total Reading Progress")
    for book in df.itertuples():
        progress_percentage = (book.Pages_Read / book.Total_Pages * 100) if book.Total_Pages > 0 else 0
        remaining_pages = book.Total_Pages - book.Pages_Read
        st.write(f"{book.Book} by {book.Author}: {book.Pages_Read}/{book.Total_Pages} pages read ({progress_percentage:.2f}%). Remaining pages: {remaining_pages}")
        st.progress(progress_percentage / 100)  # Progress bar

# Streamlit UI
st.markdown("""
    <style>
    .main {
        background-color: #2c2c2c; /* Dark gray background */
        color: #FFFFFF; /* White text color */
        padding: 20px;
        border-radius: 10px;
    }
    h1 {
        color: #FFD700; /* Gold color for titles */
    }
    h2 {
        color: #4CAF50; /* Green color for subtitles */
    }
    input {
        margin-bottom: 10px;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: 100%;
        background-color: #333333; /* Dark gray input background */
        color: #FFFFFF; /* White text color */
    }
    button {
        background-color: #4CAF50; /* Green button background */
        color: white;
        padding: 10px 15px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    button:hover {
        background-color: #45a049; /* Darker green on hover */
    }
    </style>
""", unsafe_allow_html=True)

st.title("Personal Reading Dashboard: Track & Manage Book's Reading Progress")

# Input for adding a new book
with st.container():
    st.subheader("Add a New Book")

    # Reset the fields if book is added
    if st.session_state.get('book_added', False):
        st.session_state['book_title'] = ''
        st.session_state['book_author'] = ''
        st.session_state['book_added'] = False

    book_title = st.text_input("Book Title", value=st.session_state['book_title'], key='book_title')
    book_author = st.text_input("Author", value=st.session_state['book_author'], key='book_author')
    total_pages = st.number_input("Total Pages", min_value=1, value=100)

    # Date input for date added
    date_added = st.date_input("Date Added", value=datetime.now().date())

    if st.button("Add Book"):
        if not book_title or not book_author:
            st.error("Please enter both the book title and author.")
        elif total_pages <= 0:
            st.error("Total pages must be greater than 0.")
        else:
            add_book(book_title, book_author, total_pages, date_added)
            st.success(f"Book '{book_title}' added successfully!")
            st.session_state['book_added'] = True

# Input for logging reading progress
with st.container():
    st.subheader("Log Reading Progress")
    book_choices = {book['title']: book['_id'] for book in books_collection.find()}
    
    if not book_choices:
        st.write("No books available to log progress.")
    else:
        selected_book_title = st.selectbox("Select a Book", options=list(book_choices.keys()))
        selected_book = books_collection.find_one({"_id": book_choices[selected_book_title]})

        # Display the current pages read and total pages
        pages_read = selected_book['pages_read']
        total_pages = selected_book['total_pages']

        st.write(f"Current Pages Read: {pages_read}")
        st.write(f"Total Pages: {total_pages}")

        pages_to_log = st.number_input("Number of pages read today.", min_value=0, value=0)

        if st.button("Log Progress"):
            if pages_to_log <= 0:
                st.error("Pages read must be greater than 0.")
            elif pages_read + pages_to_log > total_pages:
                st.error(f"Cannot log more than the total pages of the book. Total pages: {total_pages}.")
            else:
                log_reading_progress(book_choices[selected_book_title], pages_to_log)
                st.success(f"Logged {pages_to_log} pages for '{selected_book_title}'. New total pages read: {pages_read + pages_to_log}.")

# Input for updating a book
with st.container():
    st.subheader("Update an Existing Book")
    book_choices = {book['title']: book['_id'] for book in books_collection.find()}

    if not book_choices:
        st.write("No books available to update.")
    else:
        selected_book_title = st.selectbox("Select a Book to Update", options=list(book_choices.keys()))
        selected_book = books_collection.find_one({"_id": book_choices[selected_book_title]})

        new_title = st.text_input("New Book Title", value=selected_book['title'])
        new_author = st.text_input("New Author", value=selected_book['author'])

        if st.button("Update Book"):
            if not new_title or not new_author:
                st.error("Please enter both the book title and author.")
            else:
                update_book(book_choices[selected_book_title], new_title, new_author)
                st.success(f"Book '{selected_book_title}' updated successfully!")

# Input for deleting a book
with st.container():
    st.subheader("Delete a Book")
    book_choices = {book['title']: book['_id'] for book in books_collection.find()}

    if not book_choices:
        st.write("No books available to delete.")
    else:
        delete_book_title = st.selectbox("Select a Book to Delete", options=list(book_choices.keys()))

        if st.button("Delete Book"):
            delete_book(book_choices[delete_book_title])
            st.success(f"Book '{delete_book_title}' deleted successfully!")

# Generate report
with st.container():
    st.subheader("Generate Reading Report")
    if st.button("Generate Report"):
        generate_report()
