from flask import Flask, render_template, request
import numpy as np
import pandas as pd
import pickle
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

app = Flask(__name__)

# Load dataset
df = pd.read_csv("bigmartdata.csv")

# Select features (Removed Item_Visibility and Outlet_Establishment_Year)
features = ['Item_Weight', 'Item_Fat_Content', 'Item_Type', 'Item_MRP', 'Outlet_Location_Type']
X = df[features]
y = df["Item_Outlet_Sales"]

# Encode categorical variables
label_encoders = {}
for col in ['Item_Fat_Content', 'Item_Type', 'Outlet_Location_Type']:
    le = LabelEncoder()
    X[col] = le.fit_transform(X[col])
    label_encoders[col] = le

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save model
with open("model.pkl", "wb") as f:
    pickle.dump(model, f)

@app.route("/", methods=["GET", "POST"])
def index():
    prediction = None

    # Dropdown options
    item_fat_content_options = df['Item_Fat_Content'].unique().tolist()
    item_type_options = df['Item_Type'].unique().tolist()
    outlet_location_type_options = df['Outlet_Location_Type'].unique().tolist()

    if request.method == "POST":
        try:
            # Get form data
            item_weight = float(request.form["Item_Weight"])
            item_fat_content = request.form["Item_Fat_Content"]
            item_type = request.form["Item_Type"]
            item_mrp = float(request.form["Item_MRP"])
            outlet_location_type = request.form["Outlet_Location_Type"]

            # Convert categorical values
            item_fat_content = label_encoders["Item_Fat_Content"].transform([item_fat_content])[0]
            item_type = label_encoders["Item_Type"].transform([item_type])[0]
            outlet_location_type = label_encoders["Outlet_Location_Type"].transform([outlet_location_type])[0]

            # Make prediction
            input_features = np.array([[item_weight, item_fat_content, item_type, item_mrp, outlet_location_type]])
            prediction = model.predict(input_features)[0]

        except Exception as e:
            prediction = f"Error: {str(e)}"

    return render_template("index.html",
                           prediction=round(float(prediction), 2) if prediction else None,
                           item_fat_content_options=item_fat_content_options,
                           item_type_options=item_type_options,
                           outlet_location_type_options=outlet_location_type_options)

if __name__ == "__main__":
    app.run(debug=True)
