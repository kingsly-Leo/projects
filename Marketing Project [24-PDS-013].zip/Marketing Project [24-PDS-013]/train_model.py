import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
import joblib

# Load dataset
df = pd.read_csv("bigmartdata.csv")

# Select relevant columns (Removed Item_Visibility and Outlet_Establishment_Year)
features = ["Item_Weight", "Item_Fat_Content", "Item_Type", "Item_MRP", "Outlet_Location_Type"]
df = df[features + ["Item_Outlet_Sales"]]

# Encode categorical variables
df["Item_Fat_Content"] = df["Item_Fat_Content"].replace({"LF": "Low Fat", "low fat": "Low Fat", "reg": "Regular"})
df["Item_Fat_Content"] = df["Item_Fat_Content"].map({"Low Fat": 1, "Regular": 0})
df["Item_Type"] = df["Item_Type"].astype("category").cat.codes
df["Outlet_Location_Type"] = df["Outlet_Location_Type"].astype("category").cat.codes

# Train-test split
X = df.drop(columns=["Item_Outlet_Sales"])
y = df["Item_Outlet_Sales"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Save model
joblib.dump(model, "model.pkl")
