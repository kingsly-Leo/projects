import streamlit as st
import pandas as pd
import joblib

# Load trained model and feature columns
model, expected_columns = joblib.load('model.pkl')

st.title("💼 Employee Salary Prediction (User-Friendly)")

st.markdown("### Fill in Employee Details Below:")

# Dropdown options (use same as label encoding used during training)
education_map = {
    'Bachelors': 0, 'Some-college': 1, '11th': 2, 'HS-grad': 3,
    'Prof-school': 4, 'Assoc-acdm': 5, 'Assoc-voc': 6, '9th': 7,
    '7th-8th': 8, '12th': 9, 'Masters': 10, '1st-4th': 11,
    '10th': 12, 'Doctorate': 13, '5th-6th': 14, 'Preschool': 15
}

marital_map = {
    'Never-married': 0, 'Married-civ-spouse': 1, 'Divorced': 2,
    'Separated': 3, 'Married-spouse-absent': 4, 'Widowed': 5, 'Married-AF-spouse': 6
}

occupation_map = {
    'Tech-support': 0, 'Craft-repair': 1, 'Other-service': 2, 'Sales': 3,
    'Exec-managerial': 4, 'Prof-specialty': 5, 'Handlers-cleaners': 6,
    'Machine-op-inspct': 7, 'Adm-clerical': 8, 'Farming-fishing': 9,
    'Transport-moving': 10, 'Priv-house-serv': 11, 'Protective-serv': 12,
    'Armed-Forces': 13, 'Unknown': 14
}

gender_map = {'Female': 0, 'Male': 1}

# Collect user input
age = st.number_input("Age", 18, 90, 30)
education = st.selectbox("Education", list(education_map.keys()))
marital_status = st.selectbox("Marital Status", list(marital_map.keys()))
occupation = st.selectbox("Occupation", list(occupation_map.keys()))
gender = st.selectbox("Gender", list(gender_map.keys()))
capital_gain = st.number_input("Capital Gain", 0, 100000, 0)
capital_loss = st.number_input("Capital Loss", 0, 5000, 0)
hours_per_week = st.slider("Hours per Week", 1, 99, 40)

# Convert inputs to encoded format
input_data = {
    'age': age,
    'education': education_map[education],
    'marital-status': marital_map[marital_status],
    'occupation': occupation_map[occupation],
    'gender': gender_map[gender],
    'capital-gain': capital_gain,
    'capital-loss': capital_loss,
    'hours-per-week': hours_per_week
}

# Fill other columns with default 0 if needed
for col in expected_columns:
    if col not in input_data:
        input_data[col] = 0

# Create DataFrame in correct order
input_df = pd.DataFrame([input_data])
input_df = input_df[expected_columns]

# Prediction
if st.button("Predict Salary Level"):
    prediction = model.predict(input_df)[0]
    st.subheader("Prediction Result")
    if prediction >= 0.5:
        st.success("💰 Predicted Salary: >50K")
    else:
        st.info("🧾 Predicted Salary: <=50K")
